import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JavaHW {


    public static void main(String[] args) {

        List<Cat> cats = new ArrayList<>(10);

        Cat cat1 = new Cat("Vaska", 2);
        Cat cat2 = new Cat("Petya", 3);
        Cat cat3 = new Cat("Vaska2", 4);
        Cat cat4 = new Cat("Vaska3", 5);
        Cat cat5 = new Cat("Vaska4", 6);


        cats.add(cat1);
        cats.add(cat2);
        cats.add(cat3);
        cats.add(cat4);
        cats.add(cat5);     //добавление



        cats.remove(1);  //удаление

        System.out.println(cats.toString());



        Iterator<Cat> catIterator = cats.iterator();
        while (catIterator.hasNext()) {

            Cat nextCat = catIterator.next();
            System.out.println(nextCat);         //вывод "getAll"
        }


    }
}